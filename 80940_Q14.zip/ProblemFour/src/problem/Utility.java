package problem;

import java.util.Arrays;

public class Utility {
	public static void main(String[] args) {
		var cities = Arrays.asList("New York", "London", "Sydney", "Tokyo");
		cities.stream()
			  .filter(c->c.startsWith("S"))
			  .map(c->c.toUpperCase())
			  .forEach(System.out::println);
	}
}
