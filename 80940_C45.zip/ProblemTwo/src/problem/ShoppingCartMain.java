package problem;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Scanner;

public class ShoppingCartMain {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		
		System.out.println("Enter the collection type: ");
		String collectionType = sc.nextLine();
		Collection<Item> shoppingCart = null;
		if(collectionType.equals("ArrayList")) {
			shoppingCart = new ArrayList<Item>();
		} else if(collectionType.equals("HashSet")) {
			shoppingCart = new HashSet<Item>();
		} else {
			System.out.println("Invalid collection type!");
		}
		
		// Read item details
		System.out.println("Enter items like below\n"
				+ "<item_name> <price> <quantity>");
		
		System.out.println("Enter items details, press 0 to exit.");
		while(true) {
			String items = sc.nextLine().trim();
			if(items.charAt(0) == '0') {
				break;
			}
			String[] item_details = items.split(" ");
			String itemName = item_details[0];
			Double itemPrice = Double.parseDouble(item_details[1]);
			Integer itemQuantity = Integer.parseInt(item_details[2]); 
			shoppingCart.add(new Item(itemName, itemPrice, itemQuantity));
		}
		
		// Calculate total price
		Double totalPrice = 0.0;
		for(Item item : shoppingCart) {
			totalPrice += item.getTotalCost();
		}
		
		// Apply discount if total price exceeds $100
		Double discount = 0.0;
		if(totalPrice > 100) {
			discount = totalPrice * 0.1;
		}
		
		// Print bill
		System.out.println("Items: ");
		for(Item item : shoppingCart) {
			System.out.println("\t"+item.getItemName() + " (" + item.getQuantity() +" X $" + item.getItemPrice() + " ) " +" - $" + item.getTotalCost());
		}
		
		System.out.println("\nTotal Price: $" + totalPrice);
        System.out.println("Discount(10%): $" + discount);
        System.out.println("Final Price: $" + (totalPrice - discount));
	}
	
}
