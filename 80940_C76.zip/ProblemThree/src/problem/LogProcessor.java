package problem;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class LogProcessor {
	public static void main(String[] args) {
		
		String filename = "logs.txt";
//		String filepath = "D:\\InputFiles\\";
		try {
			Files.lines(Paths.get(filename))
											  .filter(line->!line.contains("error"))
											  .forEach(System.out::println);
 		} catch(IOException e) {
 			System.out.println(e.getMessage());
 		}
	}
}
